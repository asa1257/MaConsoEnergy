Write-Host "Vérification de l'installation..." -ForegroundColor Green

# Vérification des dépendances principales
$requiredDeps = @(
    "@mui/material",
    "@mui/icons-material",
    "react",
    "react-dom",
    "react-router-dom",
    "recharts"
)

$packageJson = Get-Content "package.json" | ConvertFrom-Json
$missingDeps = @()

foreach ($dep in $requiredDeps) {
    if (-not $packageJson.dependencies.$dep) {
        $missingDeps += $dep
    }
}

if ($missingDeps.Count -gt 0) {
    Write-Host "Dépendances manquantes:" -ForegroundColor Red
    $missingDeps | ForEach-Object { Write-Host "- $_" -ForegroundColor Red }
    exit 1
}

# Vérification de la présence du dossier src
if (-not (Test-Path "src")) {
    Write-Host "ERREUR: Le dossier src est manquant!" -ForegroundColor Red
    
    # Restauration depuis la sauvegarde si nécessaire
    if (Test-Path "src_backup") {
        Write-Host "Restauration depuis la sauvegarde..." -ForegroundColor Yellow
        Move-Item -Path "src_backup" -Destination "src" -Force
    }
    exit 1
}

# Vérification de node_modules
if (-not (Test-Path "node_modules")) {
    Write-Host "ERREUR: Le dossier node_modules est manquant!" -ForegroundColor Red
    exit 1
}

Write-Host "Installation vérifiée avec succès!" -ForegroundColor Green
Write-Host "Démarrage de l'application..." -ForegroundColor Green

# Démarrage du serveur de développement
npm run dev
