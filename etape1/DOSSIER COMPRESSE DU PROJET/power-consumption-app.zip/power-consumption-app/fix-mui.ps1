Write-Host "Correction des versions des dépendances..." -ForegroundColor Green

# Arrêt du serveur de développement si en cours
$processName = "node"
$processArgs = ".*vite.*"
Get-Process $processName | Where-Object { $_.CommandLine -match $processArgs } | Stop-Process -Force -ErrorAction SilentlyContinue

# Sauvegarde du dossier src
Write-Host "Sauvegarde des fichiers sources..." -ForegroundColor Yellow
Copy-Item -Path "src" -Destination "src_backup" -Recurse -Force

# Nettoyage du cache
Write-Host "Nettoyage du cache..." -ForegroundColor Yellow
Remove-Item -Path "node_modules/.vite" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "node_modules/.cache" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "node_modules" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "package-lock.json" -Force -ErrorAction SilentlyContinue

# Installation des versions compatibles
Write-Host "Installation des dépendances avec les bonnes versions..." -ForegroundColor Yellow

# Première étape : installation des dépendances de base
npm install --legacy-peer-deps react@18.2.0 react-dom@18.2.0

# Deuxième étape : Material-UI et ses dépendances
npm install --legacy-peer-deps @mui/material@5.15.5 @emotion/react@11.11.3 @emotion/styled@11.11.0 @mui/icons-material@5.15.5

# Troisième étape : autres dépendances
npm install --legacy-peer-deps react-router-dom@6.21.3 recharts@2.10.4

# Quatrième étape : dépendances de développement
npm install --legacy-peer-deps --save-dev @types/react@18.2.48 @types/react-dom@18.2.18 @vitejs/plugin-react@4.2.1 typescript@5.3.3 vite@5.0.12

Write-Host "Restauration des fichiers sources..." -ForegroundColor Yellow
Remove-Item -Path "src" -Recurse -Force -ErrorAction SilentlyContinue
Move-Item -Path "src_backup" -Destination "src"

Write-Host "Installation terminée. Vérification..." -ForegroundColor Green
# Exécution du script de vérification
./verify-install.ps1

Write-Host "Démarrage du serveur de développement..." -ForegroundColor Green
npm run dev
