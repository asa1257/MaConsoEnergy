import React, { useState } from 'react';
import {
  Box,
  SpeedDial,
  SpeedDialAction,
  SpeedDialIcon,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  FormControl,
  FormControlLabel,
  Checkbox,
  TextField,
  MenuItem,
} from '@mui/material';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import TableChartIcon from '@mui/icons-material/TableChart';
import EmailIcon from '@mui/icons-material/Email';

export const DataExport = () => {
  const [open, setOpen] = useState(false);
  const [exportType, setExportType] = useState('');
  const [exportOptions, setExportOptions] = useState({
    includeCharts: true,
    includeStats: true,
    includePredictions: true,
    dateRange: 'week',
    email: '',
  });

  const handleExport = (type: string) => {
    setExportType(type);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleExportConfirm = () => {
    // Simulation d'export
    console.log('Exporting...', { type: exportType, options: exportOptions });
    
    // En réalité, ici nous appellerions une API pour générer et télécharger le fichier
    setTimeout(() => {
      alert('Export réussi !');
      handleClose();
    }, 1000);
  };

  const actions = [
    { icon: <PictureAsPdfIcon />, name: 'PDF', action: () => handleExport('pdf') },
    { icon: <TableChartIcon />, name: 'Excel', action: () => handleExport('excel') },
    { icon: <EmailIcon />, name: 'Email', action: () => handleExport('email') },
  ];

  return (
    <>
      <SpeedDial
        ariaLabel="Export Options"
        sx={{ position: 'fixed', bottom: 16, right: 16 }}
        icon={<SpeedDialIcon openIcon={<FileDownloadIcon />} />}
      >
        {actions.map((action) => (
          <SpeedDialAction
            key={action.name}
            icon={action.icon}
            tooltipTitle={action.name}
            onClick={action.action}
          />
        ))}
      </SpeedDial>

      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>
          Export des données ({exportType.toUpperCase()})
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
            <FormControl component="fieldset">
              <FormControlLabel
                control={
                  <Checkbox
                    checked={exportOptions.includeCharts}
                    onChange={(e) =>
                      setExportOptions({ ...exportOptions, includeCharts: e.target.checked })
                    }
                  />
                }
                label="Inclure les graphiques"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={exportOptions.includeStats}
                    onChange={(e) =>
                      setExportOptions({ ...exportOptions, includeStats: e.target.checked })
                    }
                  />
                }
                label="Inclure les statistiques"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={exportOptions.includePredictions}
                    onChange={(e) =>
                      setExportOptions({ ...exportOptions, includePredictions: e.target.checked })
                    }
                  />
                }
                label="Inclure les prévisions"
              />
            </FormControl>

            <TextField
              select
              label="Période"
              value={exportOptions.dateRange}
              onChange={(e) =>
                setExportOptions({ ...exportOptions, dateRange: e.target.value })
              }
              fullWidth
            >
              <MenuItem value="day">Aujourd'hui</MenuItem>
              <MenuItem value="week">Cette semaine</MenuItem>
              <MenuItem value="month">Ce mois</MenuItem>
              <MenuItem value="year">Cette année</MenuItem>
            </TextField>

            {exportType === 'email' && (
              <TextField
                label="Email"
                type="email"
                value={exportOptions.email}
                onChange={(e) =>
                  setExportOptions({ ...exportOptions, email: e.target.value })
                }
                fullWidth
              />
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Annuler</Button>
          <Button onClick={handleExportConfirm} variant="contained" color="primary">
            Exporter
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};
