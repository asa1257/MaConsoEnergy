import React, { useState } from 'react';
import {
  Box,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Switch,
  TextField,
  Slider,
  Typography,
  IconButton,
  Divider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Badge,
} from '@mui/material';
import NotificationsIcon from '@mui/icons-material/Notifications';
import EditIcon from '@mui/icons-material/Edit';
import AddIcon from '@mui/icons-material/Add';

interface NotificationRule {
  id: number;
  type: string;
  threshold: number;
  enabled: boolean;
  channel: string;
  frequency: string;
}

const initialRules: NotificationRule[] = [
  {
    id: 1,
    type: 'consumption_spike',
    threshold: 4000,
    enabled: true,
    channel: 'email',
    frequency: 'immediate',
  },
  {
    id: 2,
    type: 'monthly_budget',
    threshold: 80,
    enabled: true,
    channel: 'app',
    frequency: 'daily',
  },
  {
    id: 3,
    type: 'equipment_alert',
    threshold: 1000,
    enabled: false,
    channel: 'sms',
    frequency: 'weekly',
  },
];

export const NotificationSettings = () => {
  const [open, setOpen] = useState(false);
  const [rules, setRules] = useState(initialRules);
  const [editingRule, setEditingRule] = useState<NotificationRule | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);

  const handleToggle = (id: number) => {
    setRules(rules.map(rule => 
      rule.id === id ? { ...rule, enabled: !rule.enabled } : rule
    ));
  };

  const handleEdit = (rule: NotificationRule) => {
    setEditingRule(rule);
    setEditDialogOpen(true);
  };

  const handleSaveRule = () => {
    if (editingRule) {
      setRules(rules.map(rule =>
        rule.id === editingRule.id ? editingRule : rule
      ));
    }
    setEditDialogOpen(false);
    setEditingRule(null);
  };

  const getNotificationTypeLabel = (type: string) => {
    switch (type) {
      case 'consumption_spike':
        return 'Pic de consommation';
      case 'monthly_budget':
        return 'Budget mensuel';
      case 'equipment_alert':
        return 'Alerte équipement';
      default:
        return type;
    }
  };

  return (
    <>
      <IconButton color="inherit" onClick={() => setOpen(true)}>
        <Badge badgeContent={rules.filter(r => r.enabled).length} color="error">
          <NotificationsIcon />
        </Badge>
      </IconButton>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Paramètres de Notification</DialogTitle>
        <DialogContent>
          <List>
            {rules.map((rule) => (
              <React.Fragment key={rule.id}>
                <ListItem>
                  <ListItemText
                    primary={getNotificationTypeLabel(rule.type)}
                    secondary={`Seuil: ${rule.threshold}${rule.type === 'monthly_budget' ? '%' : 'W'} | ${rule.channel} | ${rule.frequency}`}
                  />
                  <ListItemSecondaryAction>
                    <IconButton edge="end" onClick={() => handleEdit(rule)} sx={{ mr: 1 }}>
                      <EditIcon />
                    </IconButton>
                    <Switch
                      edge="end"
                      checked={rule.enabled}
                      onChange={() => handleToggle(rule.id)}
                    />
                  </ListItemSecondaryAction>
                </ListItem>
                <Divider />
              </React.Fragment>
            ))}
          </List>
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <Button
              startIcon={<AddIcon />}
              onClick={() => handleEdit({
                id: Math.max(...rules.map(r => r.id)) + 1,
                type: 'consumption_spike',
                threshold: 1000,
                enabled: true,
                channel: 'app',
                frequency: 'immediate',
              })}
            >
              Ajouter une règle
            </Button>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Fermer</Button>
        </DialogActions>
      </Dialog>

      <Dialog open={editDialogOpen} onClose={() => setEditDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingRule?.id ? 'Modifier la règle' : 'Nouvelle règle'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3, mt: 2 }}>
            <FormControl fullWidth>
              <InputLabel>Type d'alerte</InputLabel>
              <Select
                value={editingRule?.type || ''}
                onChange={(e) => setEditingRule(prev => prev ? {...prev, type: e.target.value} : null)}
              >
                <MenuItem value="consumption_spike">Pic de consommation</MenuItem>
                <MenuItem value="monthly_budget">Budget mensuel</MenuItem>
                <MenuItem value="equipment_alert">Alerte équipement</MenuItem>
              </Select>
            </FormControl>

            <Box>
              <Typography gutterBottom>
                Seuil de déclenchement
                {editingRule?.type === 'monthly_budget' ? ' (%)' : ' (W)'}
              </Typography>
              <Slider
                value={editingRule?.threshold || 0}
                onChange={(_, value) => setEditingRule(prev => prev ? {...prev, threshold: value as number} : null)}
                min={0}
                max={editingRule?.type === 'monthly_budget' ? 100 : 5000}
                step={editingRule?.type === 'monthly_budget' ? 5 : 100}
                valueLabelDisplay="auto"
              />
            </Box>

            <FormControl fullWidth>
              <InputLabel>Canal de notification</InputLabel>
              <Select
                value={editingRule?.channel || ''}
                onChange={(e) => setEditingRule(prev => prev ? {...prev, channel: e.target.value} : null)}
              >
                <MenuItem value="app">Application</MenuItem>
                <MenuItem value="email">Email</MenuItem>
                <MenuItem value="sms">SMS</MenuItem>
              </Select>
            </FormControl>

            <FormControl fullWidth>
              <InputLabel>Fréquence</InputLabel>
              <Select
                value={editingRule?.frequency || ''}
                onChange={(e) => setEditingRule(prev => prev ? {...prev, frequency: e.target.value} : null)}
              >
                <MenuItem value="immediate">Immédiate</MenuItem>
                <MenuItem value="daily">Quotidienne</MenuItem>
                <MenuItem value="weekly">Hebdomadaire</MenuItem>
              </Select>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditDialogOpen(false)}>Annuler</Button>
          <Button onClick={handleSaveRule} variant="contained" color="primary">
            Enregistrer
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};
