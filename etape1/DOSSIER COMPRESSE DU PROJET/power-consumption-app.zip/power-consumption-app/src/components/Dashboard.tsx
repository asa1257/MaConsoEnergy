import React, { useState } from 'react';
import {
  Box,
  Container,
  Grid,
  Paper,
  Typography,
  ToggleButton,
  ToggleButtonGroup,
  Alert,
  IconButton,
  Menu,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  SelectChangeEvent,
  LinearProgress,
} from '@mui/material';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Cell,
} from 'recharts';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import FilterListIcon from '@mui/icons-material/FilterList';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import TrendingDownIcon from '@mui/icons-material/TrendingDown';
import WarningIcon from '@mui/icons-material/Warning';

// Données pour le graphique principal
const weeklyData = [
  { name: 'Lun', consommation: 400, moyenne: 350 },
  { name: 'Mar', consommation: 300, moyenne: 350 },
  { name: 'Mer', consommation: 500, moyenne: 350 },
  { name: 'Jeu', consommation: 280, moyenne: 350 },
  { name: 'Ven', consommation: 390, moyenne: 350 },
  { name: 'Sam', consommation: 230, moyenne: 350 },
  { name: 'Dim', consommation: 200, moyenne: 350 },
];

// Données pour la répartition par type
const consumptionByType = [
  { name: 'Chauffage', value: 450, color: '#2e7d32' },
  { name: 'Éclairage', value: 200, color: '#1976d2' },
  { name: 'Électroménager', value: 300, color: '#ed6c02' },
  { name: 'Multimédia', value: 150, color: '#9c27b0' },
];

// Données pour les alertes
const alerts = [
  {
    severity: 'warning',
    message: 'Consommation inhabituelle détectée hier (+25%)',
  },
  {
    severity: 'info',
    message: 'Vous avez atteint 80% de votre objectif mensuel',
  },
];

import { AdvancedFilters } from './AdvancedFilters';
import { PredictionChart } from './PredictionChart';
import { DataExport } from './DataExport';
import { OptimizationTips } from './OptimizationTips';
import { NotificationSettings } from './NotificationSettings';

export const Dashboard = () => {
  const [timeRange, setTimeRange] = useState('week');
  const [chartType, setChartType] = useState('line');
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedMetric, setSelectedMetric] = useState('consommation');

  const handleTimeRangeChange = (event: React.MouseEvent<HTMLElement>, newValue: string) => {
    if (newValue !== null) {
      setTimeRange(newValue);
    }
  };

  const handleChartTypeChange = (event: React.MouseEvent<HTMLElement>, newValue: string) => {
    if (newValue !== null) {
      setChartType(newValue);
    }
  };

  const handleMetricChange = (event: SelectChangeEvent) => {
    setSelectedMetric(event.target.value);
  };

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const getProgressColor = (value: number) => {
    if (value < 60) return 'success';
    if (value < 80) return 'warning';
    return 'error';
  };

  const handleFiltersChange = (filters: any) => {
    console.log('Nouveaux filtres:', filters);
    // Ici, nous mettrions à jour les données en fonction des filtres
  };

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
        <NotificationSettings />
      </Box>

      {/* Alertes */}
      <Box sx={{ mb: 3 }}>
        {alerts.map((alert, index) => (
          <Alert
            key={index}
            severity={alert.severity as 'warning' | 'info'}
            sx={{ mb: 1 }}
            icon={alert.severity === 'warning' ? <WarningIcon /> : undefined}
          >
            {alert.message}
          </Alert>
        ))}
      </Box>

      {/* Filtres avancés */}
      <AdvancedFilters onFiltersChange={handleFiltersChange} />

      <Grid container spacing={3}>
        {/* Graphique principal */}
        <Grid item xs={12} lg={8}>
          <Paper
            sx={{
              p: 3,
              display: 'flex',
              flexDirection: 'column',
              height: 450,
              backgroundImage: 'linear-gradient(to bottom right, #ffffff, #f1f8e9)',
            }}
          >
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6" color="primary.dark">
                Suivi de Consommation
              </Typography>
              <Box sx={{ display: 'flex', gap: 2 }}>
                <ToggleButtonGroup
                  size="small"
                  value={timeRange}
                  exclusive
                  onChange={handleTimeRangeChange}
                >
                  <ToggleButton value="day">Jour</ToggleButton>
                  <ToggleButton value="week">Semaine</ToggleButton>
                  <ToggleButton value="month">Mois</ToggleButton>
                </ToggleButtonGroup>
                <ToggleButtonGroup
                  size="small"
                  value={chartType}
                  exclusive
                  onChange={handleChartTypeChange}
                >
                  <ToggleButton value="line">Ligne</ToggleButton>
                  <ToggleButton value="bar">Barres</ToggleButton>
                </ToggleButtonGroup>
                <FormControl size="small" sx={{ minWidth: 120 }}>
                  <InputLabel>Métrique</InputLabel>
                  <Select
                    value={selectedMetric}
                    label="Métrique"
                    onChange={handleMetricChange}
                  >
                    <MenuItem value="consommation">Consommation</MenuItem>
                    <MenuItem value="cout">Coût</MenuItem>
                    <MenuItem value="co2">CO2</MenuItem>
                  </Select>
                </FormControl>
              </Box>
            </Box>
            <Box sx={{ flexGrow: 1, width: '100%' }}>
              <ResponsiveContainer>
                {chartType === 'line' ? (
                  <LineChart data={weeklyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="consommation"
                      stroke="#2e7d32"
                      strokeWidth={2}
                      name="Consommation"
                    />
                    <Line
                      type="monotone"
                      dataKey="moyenne"
                      stroke="#1976d2"
                      strokeWidth={2}
                      strokeDasharray="5 5"
                      name="Moyenne"
                    />
                  </LineChart>
                ) : (
                  <BarChart data={weeklyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="consommation" fill="#2e7d32" name="Consommation" />
                    <Bar dataKey="moyenne" fill="#1976d2" name="Moyenne" />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </Box>
          </Paper>
        </Grid>

        {/* Indicateurs et statistiques */}
        <Grid item xs={12} lg={4}>
          <Grid container spacing={3}>
            {/* Consommation actuelle */}
            <Grid item xs={12}>
              <Paper
                sx={{
                  p: 3,
                  backgroundImage: 'linear-gradient(to bottom right, #ffffff, #e3f2fd)',
                }}
              >
                <Typography variant="h6" gutterBottom color="primary.dark">
                  Consommation Actuelle
                </Typography>
                <Typography variant="h3" color="primary.main" sx={{ my: 2 }}>
                  2.4 kW
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <TrendingUpIcon color="success" />
                  <Typography variant="body2" color="success.main">
                    +5% par rapport à hier
                  </Typography>
                </Box>
              </Paper>
            </Grid>

            {/* Objectif mensuel */}
            <Grid item xs={12}>
              <Paper
                sx={{
                  p: 3,
                  backgroundImage: 'linear-gradient(to bottom right, #ffffff, #e3f2fd)',
                }}
              >
                <Typography variant="h6" gutterBottom color="primary.dark">
                  Objectif Mensuel
                </Typography>
                <Box sx={{ mt: 2, mb: 1 }}>
                  <Typography variant="body2" color="text.secondary">
                    Progression: 75%
                  </Typography>
                  <LinearProgress
                    variant="determinate"
                    value={75}
                    color={getProgressColor(75)}
                    sx={{ height: 8, borderRadius: 4, mt: 1 }}
                  />
                </Box>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                  450 kWh sur 600 kWh
                </Typography>
              </Paper>
            </Grid>

            {/* Répartition par type */}
            <Grid item xs={12}>
              <Paper
                sx={{
                  p: 3,
                  backgroundImage: 'linear-gradient(to bottom right, #ffffff, #e3f2fd)',
                  height: '100%',
                }}
              >
                <Typography variant="h6" gutterBottom color="primary.dark">
                  Répartition par Type
                </Typography>
                <Box sx={{ height: 200, mt: 2 }}>
                  <ResponsiveContainer>
                    <PieChart>
                      <Pie
                        data={consumptionByType}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        label
                      >
                        {consumptionByType.map((entry, index) => (
                          <Cell key={index} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Grid>

        {/* Prévisions de consommation */}
        <Grid item xs={12}>
          <Paper
            sx={{
              p: 3,
              backgroundImage: 'linear-gradient(to bottom right, #ffffff, #f1f8e9)',
            }}
          >
            <Typography variant="h6" gutterBottom color="primary.dark">
              Prévisions de Consommation
            </Typography>
            <PredictionChart />
          </Paper>
        </Grid>

        {/* Conseils d'optimisation */}
        <Grid item xs={12}>
          <OptimizationTips />
        </Grid>
      </Grid>

      {/* Bouton d'export flottant */}
      <DataExport />
    </Container>
  );
};
