import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Slider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  IconButton,
  Collapse,
  SelectChangeEvent,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';

interface FilterProps {
  onFiltersChange: (filters: any) => void;
}

export const AdvancedFilters = ({ onFiltersChange }: FilterProps) => {
  const [expanded, setExpanded] = useState(false);
  const [selectedEquipments, setSelectedEquipments] = useState<string[]>([]);
  const [consumptionRange, setConsumptionRange] = useState<number[]>([0, 5000]);
  const [timeFrame, setTimeFrame] = useState('day');

  const equipments = [
    'Chauffage',
    'Climatisation',
    'Éclairage',
    'Électroménager',
    'Multimédia',
    'Autres',
  ];

  const handleEquipmentChange = (event: SelectChangeEvent<string[]>) => {
    const value = event.target.value as string[];
    setSelectedEquipments(value);
    updateFilters(value, consumptionRange, timeFrame);
  };

  const handleConsumptionChange = (event: Event, newValue: number | number[]) => {
    setConsumptionRange(newValue as number[]);
    updateFilters(selectedEquipments, newValue as number[], timeFrame);
  };

  const handleTimeFrameChange = (event: SelectChangeEvent) => {
    setTimeFrame(event.target.value);
    updateFilters(selectedEquipments, consumptionRange, event.target.value);
  };

  const updateFilters = (equipment: string[], consumption: number[], time: string) => {
    onFiltersChange({
      equipment,
      consumption,
      timeFrame: time,
    });
  };

  return (
    <Paper sx={{ p: 2, mb: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Typography variant="h6" color="primary.dark">
          Filtres Avancés
        </Typography>
        <IconButton onClick={() => setExpanded(!expanded)}>
          {expanded ? <ExpandLessIcon /> : <ExpandMoreIcon />}
        </IconButton>
      </Box>

      <Collapse in={expanded}>
        <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 3 }}>
          {/* Sélection des équipements */}
          <FormControl>
            <InputLabel>Équipements</InputLabel>
            <Select
              multiple
              value={selectedEquipments}
              onChange={handleEquipmentChange}
              renderValue={(selected) => (
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {(selected as string[]).map((value) => (
                    <Chip key={value} label={value} size="small" />
                  ))}
                </Box>
              )}
            >
              {equipments.map((name) => (
                <MenuItem key={name} value={name}>
                  {name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          {/* Plage de consommation */}
          <Box>
            <Typography gutterBottom>
              Plage de Consommation (kWh)
            </Typography>
            <Slider
              value={consumptionRange}
              onChange={handleConsumptionChange}
              valueLabelDisplay="auto"
              min={0}
              max={5000}
              step={100}
            />
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography variant="body2" color="text.secondary">
                {consumptionRange[0]} kWh
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {consumptionRange[1]} kWh
              </Typography>
            </Box>
          </Box>

          {/* Période */}
          <FormControl>
            <InputLabel>Période</InputLabel>
            <Select
              value={timeFrame}
              onChange={handleTimeFrameChange}
              label="Période"
            >
              <MenuItem value="hour">Par heure</MenuItem>
              <MenuItem value="day">Par jour</MenuItem>
              <MenuItem value="week">Par semaine</MenuItem>
              <MenuItem value="month">Par mois</MenuItem>
            </Select>
          </FormControl>
        </Box>
      </Collapse>
    </Paper>
  );
};
