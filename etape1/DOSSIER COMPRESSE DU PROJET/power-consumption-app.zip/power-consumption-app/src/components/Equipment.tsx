import React, { useState, useMemo } from 'react';
import {
  Box,
  Container,
  Typography,
  Paper,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Tabs,
  Tab,
  Tooltip,
  Alert,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import ElectricBoltIcon from '@mui/icons-material/ElectricBolt';
import KitchenIcon from '@mui/icons-material/Kitchen';
import TvIcon from '@mui/icons-material/Tv';
import AcUnitIcon from '@mui/icons-material/AcUnit';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';

// Types pour les équipements
interface Equipment {
  id: number;
  name: string;
  type: string;
  consumption: number;
  status: 'active' | 'inactive';
  location: string;
}

interface FormData {
  name: string;
  type: string;
  consumption: number;
  location: string;
  status: 'active' | 'inactive';
}

const equipmentTypes = [
  { value: 'Électroménager', icon: <KitchenIcon />, color: '#2196f3' },
  { value: 'Multimédia', icon: <TvIcon />, color: '#9c27b0' },
  { value: 'Climatisation', icon: <AcUnitIcon />, color: '#00bcd4' },
  { value: 'Éclairage', icon: <LightbulbIcon />, color: '#ffc107' },
];

const initialFormData: FormData = {
  name: '',
  type: 'Électroménager',
  consumption: 0,
  location: '',
  status: 'active',
};

// Données factices pour les équipements
const initialEquipments: Equipment[] = [
  { id: 1, name: 'Réfrigérateur', type: 'Électroménager', consumption: 150, status: 'active', location: 'Cuisine' },
  { id: 2, name: 'Lave-linge', type: 'Électroménager', consumption: 500, status: 'inactive', location: 'Buanderie' },
  { id: 3, name: 'Télévision', type: 'Multimédia', consumption: 100, status: 'active', location: 'Salon' },
  { id: 4, name: 'Climatiseur', type: 'Climatisation', consumption: 1000, status: 'active', location: 'Salon' },
  { id: 5, name: 'Lampes LED', type: 'Éclairage', consumption: 50, status: 'active', location: 'Salon' },
];

export const Equipment = () => {
  const [equipments, setEquipments] = useState<Equipment[]>(initialEquipments);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedEquipment, setSelectedEquipment] = useState<Equipment | null>(null);
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [currentTab, setCurrentTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredEquipments = useMemo(() => {
    return equipments.filter(equipment => {
      const matchesSearch = equipment.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          equipment.location.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesTab = currentTab === 'all' || equipment.type === currentTab;
      return matchesSearch && matchesTab;
    });
  }, [equipments, searchQuery, currentTab]);

  const handleOpenDialog = (equipment?: Equipment) => {
    if (equipment) {
      setSelectedEquipment(equipment);
      setFormData({
        name: equipment.name,
        type: equipment.type,
        consumption: equipment.consumption,
        location: equipment.location,
        status: equipment.status,
      });
    } else {
      setSelectedEquipment(null);
      setFormData(initialFormData);
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedEquipment(null);
    setFormData(initialFormData);
  };

  const handleInputChange = (field: keyof FormData, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = () => {
    if (!formData.name || !formData.location || formData.consumption <= 0) {
      alert('Veuillez remplir tous les champs correctement');
      return;
    }

    if (selectedEquipment) {
      setEquipments(prev =>
        prev.map(eq =>
          eq.id === selectedEquipment.id
            ? { ...eq, ...formData }
            : eq
        )
      );
    } else {
      const newEquipment: Equipment = {
        id: Math.max(...equipments.map(eq => eq.id)) + 1,
        ...formData
      };
      setEquipments(prev => [...prev, newEquipment]);
    }
    handleCloseDialog();
  };

  const handleDelete = (id: number) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer cet équipement ?')) {
      setEquipments(prev => prev.filter(eq => eq.id !== id));
    }
  };

  const handleToggleStatus = (id: number) => {
    setEquipments(prev =>
      prev.map(eq =>
        eq.id === id
          ? { ...eq, status: eq.status === 'active' ? 'inactive' : 'active' }
          : eq
      )
    );
  };

  const getStatusColor = (status: string) => {
    return status === 'active' ? 'success' : 'error';
  };

  const getTypeIcon = (type: string) => {
    const equipmentType = equipmentTypes.find(t => t.value === type);
    return equipmentType?.icon || <ElectricBoltIcon />;
  };

  const getTypeColor = (type: string) => {
    const equipmentType = equipmentTypes.find(t => t.value === type);
    return equipmentType?.color || '#757575';
  };

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      {/* En-tête avec recherche et filtres */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" color="primary.main">
          Équipements
        </Typography>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <TextField
            size="small"
            placeholder="Rechercher..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            InputProps={{
              startAdornment: <SearchIcon sx={{ mr: 1 }} />,
            }}
          />
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => handleOpenDialog()}
            sx={{
              background: 'linear-gradient(45deg, #2e7d32 30%, #1976d2 90%)',
              color: 'white',
            }}
          >
            Ajouter
          </Button>
        </Box>
      </Box>

      {/* Filtres par type */}
      <Tabs
        value={currentTab}
        onChange={(_, newValue) => setCurrentTab(newValue)}
        sx={{ mb: 3 }}
        variant="scrollable"
        scrollButtons="auto"
      >
        <Tab
          label="Tous"
          value="all"
          icon={<FilterListIcon />}
          iconPosition="start"
        />
        {equipmentTypes.map((type) => (
          <Tab
            key={type.value}
            label={type.value}
            value={type.value}
            icon={type.icon}
            iconPosition="start"
          />
        ))}
      </Tabs>

      <Grid container spacing={3}>
        {/* Résumé de la consommation */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3, backgroundImage: 'linear-gradient(to right, #f1f8e9, #e3f2fd)' }}>
            <Grid container spacing={3}>
              <Grid item xs={12} md={4}>
                <Typography variant="h6" gutterBottom>
                  Consommation Totale
                </Typography>
                <Typography variant="h4" color="primary.main">
                  {equipments.reduce((acc, eq) => acc + (eq.status === 'active' ? eq.consumption : 0), 0)} W
                </Typography>
              </Grid>
              <Grid item xs={12} md={4}>
                <Typography variant="h6" gutterBottom>
                  Équipements Actifs
                </Typography>
                <Typography variant="h4" color="success.main">
                  {equipments.filter(eq => eq.status === 'active').length}
                </Typography>
              </Grid>
              <Grid item xs={12} md={4}>
                <Typography variant="h6" gutterBottom>
                  Total Équipements
                </Typography>
                <Typography variant="h4" color="secondary.main">
                  {equipments.length}
                </Typography>
              </Grid>
            </Grid>
          </Paper>
        </Grid>

        {/* Liste des équipements */}
        {filteredEquipments.length === 0 ? (
          <Grid item xs={12}>
            <Alert severity="info">
              Aucun équipement ne correspond à vos critères de recherche.
            </Alert>
          </Grid>
        ) : (
          filteredEquipments.map((equipment) => (
            <Grid item xs={12} md={6} lg={4} key={equipment.id}>
              <Card sx={{ 
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                '&:hover': { 
                  boxShadow: 6,
                  transform: 'translateY(-2px)',
                  transition: 'all 0.2s ease-in-out'
                }
              }}>
                <CardContent sx={{ flexGrow: 1 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Box sx={{ 
                        color: getTypeColor(equipment.type),
                        display: 'flex',
                        alignItems: 'center'
                      }}>
                        {getTypeIcon(equipment.type)}
                      </Box>
                      <Typography variant="h6" component="div">
                        {equipment.name}
                      </Typography>
                    </Box>
                    <Tooltip title="Cliquez pour changer le statut">
                      <Chip
                        label={equipment.status === 'active' ? 'Actif' : 'Inactif'}
                        color={getStatusColor(equipment.status)}
                        size="small"
                        onClick={() => handleToggleStatus(equipment.id)}
                        sx={{ cursor: 'pointer' }}
                      />
                    </Tooltip>
                  </Box>
                  <Typography color="text.secondary" gutterBottom>
                    {equipment.type}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Localisation: {equipment.location}
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', mt: 2 }}>
                    <ElectricBoltIcon color="primary" />
                    <Typography variant="h6" color="primary.main" sx={{ ml: 1 }}>
                      {equipment.consumption} W
                    </Typography>
                  </Box>
                </CardContent>
                <CardActions sx={{ justifyContent: 'flex-end', p: 2 }}>
                  <Tooltip title="Modifier">
                    <IconButton size="small" onClick={() => handleOpenDialog(equipment)}>
                      <EditIcon />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Supprimer">
                    <IconButton size="small" color="error" onClick={() => handleDelete(equipment.id)}>
                      <DeleteIcon />
                    </IconButton>
                  </Tooltip>
                </CardActions>
              </Card>
            </Grid>
          ))
        )}
      </Grid>

      {/* Dialog pour ajouter/modifier un équipement */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>
          {selectedEquipment ? 'Modifier l\'équipement' : 'Ajouter un équipement'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
            <TextField
              label="Nom de l'équipement"
              fullWidth
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              required
              error={!formData.name}
              helperText={!formData.name && "Le nom est requis"}
            />
            <FormControl fullWidth required>
              <InputLabel>Type d'équipement</InputLabel>
              <Select
                value={formData.type}
                label="Type d'équipement"
                onChange={(e) => handleInputChange('type', e.target.value)}
              >
                {equipmentTypes.map((type) => (
                  <MenuItem key={type.value} value={type.value}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      {type.icon}
                      <span>{type.value}</span>
                    </Box>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <TextField
              label="Consommation (W)"
              type="number"
              fullWidth
              value={formData.consumption}
              onChange={(e) => handleInputChange('consumption', Number(e.target.value))}
              required
              error={formData.consumption <= 0}
              helperText={formData.consumption <= 0 && "La consommation doit être supérieure à 0"}
            />
            <TextField
              label="Localisation"
              fullWidth
              value={formData.location}
              onChange={(e) => handleInputChange('location', e.target.value)}
              required
              error={!formData.location}
              helperText={!formData.location && "La localisation est requise"}
            />
          </Box>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button onClick={handleCloseDialog}>Annuler</Button>
          <Button
            variant="contained"
            onClick={handleSave}
            sx={{
              background: 'linear-gradient(45deg, #2e7d32 30%, #1976d2 90%)',
            }}
          >
            {selectedEquipment ? 'Modifier' : 'Ajouter'}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};
