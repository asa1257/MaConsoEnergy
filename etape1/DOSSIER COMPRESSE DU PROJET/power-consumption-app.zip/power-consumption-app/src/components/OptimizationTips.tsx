import React, { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Card,
  CardContent,
  CardActions,
  Button,
  Chip,
  IconButton,
  Collapse,
  LinearProgress,
} from '@mui/material';
import TipsAndUpdatesIcon from '@mui/icons-material/TipsAndUpdates';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import SavingsIcon from '@mui/icons-material/Savings';
import NatureIcon from '@mui/icons-material/Nature';
import ElectricMeterIcon from '@mui/icons-material/ElectricMeter';

interface Tip {
  id: number;
  title: string;
  description: string;
  impact: number;
  category: 'économie' | 'écologie' | 'performance';
  difficulty: 'facile' | 'moyen' | 'difficile';
  savings: number;
}

const tips: Tip[] = [
  {
    id: 1,
    title: 'Optimisation du chauffage',
    description: 'Réduisez la température de 1°C pendant la nuit pour économiser jusqu\'à 7% sur votre facture de chauffage.',
    impact: 70,
    category: 'économie',
    difficulty: 'facile',
    savings: 150,
  },
  {
    id: 2,
    title: 'Éclairage intelligent',
    description: 'Installez des détecteurs de présence dans les couloirs et pièces peu utilisées.',
    impact: 40,
    category: 'performance',
    difficulty: 'moyen',
    savings: 80,
  },
  {
    id: 3,
    title: 'Appareils en veille',
    description: 'Utilisez des prises programmables pour couper l\'alimentation des appareils en veille la nuit.',
    impact: 55,
    category: 'écologie',
    difficulty: 'facile',
    savings: 120,
  },
];

export const OptimizationTips = () => {
  const [expandedTip, setExpandedTip] = useState<number | null>(null);
  
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'économie':
        return <SavingsIcon />;
      case 'écologie':
        return <NatureIcon />;
      case 'performance':
        return <ElectricMeterIcon />;
      default:
        return <TipsAndUpdatesIcon />;
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'facile':
        return 'success';
      case 'moyen':
        return 'warning';
      case 'difficile':
        return 'error';
      default:
        return 'default';
    }
  };

  const getImpactColor = (impact: number) => {
    if (impact >= 70) return 'success';
    if (impact >= 40) return 'warning';
    return 'error';
  };

  return (
    <Paper sx={{ p: 3, backgroundImage: 'linear-gradient(to bottom right, #ffffff, #e8f5e9)' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
        <TipsAndUpdatesIcon color="primary" />
        <Typography variant="h6" color="primary.dark">
          Conseils d'Optimisation
        </Typography>
      </Box>

      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {tips.map((tip) => (
          <Card key={tip.id} variant="outlined">
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                  <Typography variant="h6" gutterBottom>
                    {tip.title}
                  </Typography>
                  <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
                    <Chip
                      icon={getCategoryIcon(tip.category)}
                      label={tip.category}
                      size="small"
                    />
                    <Chip
                      label={tip.difficulty}
                      color={getDifficultyColor(tip.difficulty) as any}
                      size="small"
                    />
                    <Chip
                      icon={<SavingsIcon />}
                      label={`${tip.savings}€/an`}
                      size="small"
                      color="primary"
                    />
                  </Box>
                </Box>
                <IconButton
                  onClick={() => setExpandedTip(expandedTip === tip.id ? null : tip.id)}
                  sx={{ transform: expandedTip === tip.id ? 'rotate(180deg)' : 'none' }}
                >
                  <ExpandMoreIcon />
                </IconButton>
              </Box>

              <Box sx={{ mt: 1 }}>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  Impact sur la consommation
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <LinearProgress
                    variant="determinate"
                    value={tip.impact}
                    color={getImpactColor(tip.impact)}
                    sx={{ flexGrow: 1, height: 8, borderRadius: 4 }}
                  />
                  <Typography variant="body2" color="text.secondary">
                    {tip.impact}%
                  </Typography>
                </Box>
              </Box>

              <Collapse in={expandedTip === tip.id}>
                <Typography sx={{ mt: 2 }}>
                  {tip.description}
                </Typography>
              </Collapse>
            </CardContent>
            <CardActions>
              <Button size="small" color="primary">
                En savoir plus
              </Button>
              <Button size="small" color="primary">
                Appliquer
              </Button>
            </CardActions>
          </Card>
        ))}
      </Box>
    </Paper>
  );
};
