import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from 'recharts';
import { Box, Typography, Paper } from '@mui/material';

// Données de prévision simulées
const predictionData = [
  { date: '08:00', actual: 2.1, predicted: null },
  { date: '09:00', actual: 2.3, predicted: null },
  { date: '10:00', actual: 2.8, predicted: null },
  { date: '11:00', actual: 3.2, predicted: null },
  { date: '12:00', actual: 2.9, predicted: 2.9 },
  { date: '13:00', actual: null, predicted: 3.1 },
  { date: '14:00', actual: null, predicted: 3.4 },
  { date: '15:00', actual: null, predicted: 3.2 },
  { date: '16:00', actual: null, predicted: 2.8 },
  { date: '17:00', actual: null, predicted: 3.0 },
  { date: '18:00', actual: null, predicted: 3.5 },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <Paper sx={{ p: 2, backgroundColor: 'rgba(255, 255, 255, 0.9)' }}>
        <Typography variant="subtitle2">{label}</Typography>
        {payload.map((item: any, index: number) => (
          <Typography
            key={index}
            variant="body2"
            sx={{ color: item.color }}
          >
            {item.name}: {item.value} kW
          </Typography>
        ))}
      </Paper>
    );
  }
  return null;
};

export const PredictionChart = () => {
  return (
    <Box sx={{ width: '100%', height: 300 }}>
      <ResponsiveContainer>
        <LineChart data={predictionData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis domain={['auto', 'auto']} />
          <Tooltip content={<CustomTooltip />} />
          <Legend />
          <ReferenceLine x="12:00" stroke="#666" label="Maintenant" />
          <Line
            type="monotone"
            dataKey="actual"
            stroke="#2e7d32"
            strokeWidth={2}
            name="Consommation réelle"
            dot={{ r: 4 }}
          />
          <Line
            type="monotone"
            dataKey="predicted"
            stroke="#1976d2"
            strokeWidth={2}
            strokeDasharray="5 5"
            name="Prévision"
            dot={{ r: 4 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </Box>
  );
};
