# Application de Gestion de Consommation Électrique

Cette application React permet de suivre et d'optimiser la consommation électrique de vos appareils.

## Prérequis

- [Node.js](https://nodejs.org/) (version 18.x ou supérieure)
- [Visual Studio Code](https://code.visualstudio.com/)
- npm (inclus avec Node.js)

## Extensions VSCode Recommandées

- ESLint
- Prettier
- TypeScript and JavaScript Language Features
- Material Icon Theme
- Auto Import
- Path Intellisense

## Installation

1. Clonez le projet :
```bash
git clone [URL_DU_PROJET]
cd power-consumption-app
```

2. Installez les dépendances :
```bash
npm install
```

## Dépendances Principales

```json
{
  "dependencies": {
    "@emotion/react": "^11.11.0",
    "@emotion/styled": "^11.11.0",
    "@mui/icons-material": "^5.11.16",
    "@mui/material": "^5.13.0",
    "@types/react-router-dom": "^5.3.3",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.11.2",
    "recharts": "^2.6.2"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "@typescript-eslint/eslint-plugin": "^5.59.6",
    "@typescript-eslint/parser": "^5.59.6",
    "@vitejs/plugin-react": "^4.0.0",
    "eslint": "^8.40.0",
    "eslint-plugin-react-hooks": "^4.6.0",
    "eslint-plugin-react-refresh": "^0.4.1",
    "typescript": "^5.0.4",
    "vite": "^4.3.8"
  }
}
```

## Scripts Disponibles

- Démarrer le serveur de développement :
```bash
npm run dev
```

- Construire l'application pour la production :
```bash
npm run build
```

- Lancer le linter :
```bash
npm run lint
```

- Prévisualiser la version de production :
```bash
npm run preview
```

## Structure du Projet

```
power-consumption-app/
├── src/
│   ├── components/
│   │   ├── Dashboard.tsx
│   │   ├── Equipment.tsx
│   │   ├── Login.tsx
│   │   └── OptimizationTips.tsx
│   ├── App.tsx
│   └── main.tsx
├── public/
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
└── README.md
```

## Configuration de l'Environnement de Développement

1. Ouvrez le projet dans VSCode :
```bash
code .
```

2. Installez les extensions recommandées

3. Configurez ESLint et Prettier :
   - Créez un fichier `.eslintrc.json` si nécessaire
   - Activez "Format on Save" dans VSCode

4. Configurez TypeScript :
   - Le fichier `tsconfig.json` est déjà configuré
   - Assurez-vous que VSCode utilise la version de TypeScript du projet

## Résolution des Problèmes Courants

1. Si vous rencontrez des erreurs de dépendances :
```bash
rm -rf node_modules
rm package-lock.json
npm install
```

2. Si le port 3000 est déjà utilisé :
   - Modifiez le port dans `vite.config.ts`
   - Ou terminez le processus qui utilise le port

3. Pour les erreurs TypeScript :
```bash
npm run build
```
Cela vous montrera toutes les erreurs de type

## Support

Pour toute question ou problème :
1. Consultez la documentation des dépendances :
   - [React](https://reactjs.org/)
   - [Material-UI](https://mui.com/)
   - [React Router](https://reactrouter.com/)
   - [Recharts](https://recharts.org/)
   - [Vite](https://vitejs.dev/)

2. Vérifiez les versions des dépendances dans package.json

3. Assurez-vous que Node.js est à jour
